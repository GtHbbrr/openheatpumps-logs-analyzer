﻿(() => {
  if (!location.hostname.includes('openquatt') && !document.querySelector('esp-app')) return;
  if (document.getElementById('oq-ai-fab')) return;

  const baseUrl = ['https://', 'openheatpumps', '.nl'].join('');
  let drawer = null;
  let open = false;

  const fab = document.createElement('button');
  fab.id = 'oq-ai-fab';
  fab.textContent = '✨ AI Hulp';
  fab.style.cssText = 'position:fixed;bottom:18px;right:18px;z-index:99998;background:#ea580c;color:#fff;border:none;border-radius:9999px;padding:10px 16px;font-family:system-ui,sans-serif;font-size:13px;font-weight:700;box-shadow:0 6px 20px rgba(0,0,0,.35);cursor:pointer';
  document.body.appendChild(fab);

  function ensureDrawer() {
    if (drawer) return;
    drawer = document.createElement('aside');
    drawer.id = 'oq-ai-drawer';
    drawer.style.cssText = 'position:fixed;top:0;right:0;width:440px;max-width:100vw;height:100vh;z-index:99999;border-left:1px solid #1f2937;background:#030712;box-shadow:-8px 0 24px rgba(0,0,0,.45);display:none';

    const closeBtn = document.createElement('button');
    closeBtn.textContent = '✕';
    closeBtn.title = 'Sluit AI zijpaneel';
    closeBtn.style.cssText = 'position:absolute;top:6px;right:10px;z-index:100000;background:#1f2937;color:#d1d5db;border:1px solid #374151;border-radius:4px;padding:2px 7px;font-size:12px;cursor:pointer';
    closeBtn.onclick = () => toggleDrawer(false);

    const iframe = document.createElement('iframe');
    iframe.src = baseUrl + '/?embed=1';
    iframe.style.cssText = 'width:100%;height:100%;border:0';

    drawer.append(closeBtn, iframe);
    document.body.appendChild(drawer);

    window.addEventListener('message', async (e) => {
      if (e.data?.type === 'OQ_EMBED_READY') {
        try {
          const res = await fetch('/openquatt/debug-recording/download?last_minutes=15');
          if (res.ok) {
            const logData = await res.json();
            iframe.contentWindow.postMessage({ type: 'OQ_LOGDATA', logData }, baseUrl);
          }
        } catch (_) {}
      } else if (e.data?.type === 'OQ_NAVIGATE' && e.data.href) {
        const u = new URL(e.data.href);
        history.pushState({}, '', u.search);
        window.dispatchEvent(new PopStateEvent('popstate'));
      }
    });
  }

  function toggleDrawer(forceState) {
    ensureDrawer();
    open = typeof forceState === 'boolean' ? forceState : !open;
    drawer.style.display = open ? 'block' : 'none';
    document.body.style.transition = 'margin-right 0.2s ease';
    document.body.style.marginRight = open ? '440px' : '0';
    fab.style.display = open ? 'none' : 'block';
  }

  fab.onclick = () => toggleDrawer(true);
})();
