﻿(() => {
  if (!location.hostname.includes('openquatt') && !document.querySelector('esp-app')) return;
  if (document.getElementById('oq-ai-toggle')) return;

  const baseUrl = ['https://', 'openheatpumps', '.nl'].join('');
  let drawer = null;
  let open = false;
  const windowMinutes = 15;

  const toggleBtn = document.createElement('button');
  toggleBtn.id = 'oq-ai-toggle';
  toggleBtn.textContent = '✨ AI Hulp';
  toggleBtn.style.cssText = 'position:fixed;top:12px;right:16px;z-index:100000;background:#ea580c;color:#fff;border:1px solid #f97316;border-radius:9999px;padding:7px 14px;font-family:system-ui,sans-serif;font-size:13px;font-weight:700;box-shadow:0 4px 14px rgba(0,0,0,.3);cursor:pointer;transition:all 0.2s ease';
  document.body.appendChild(toggleBtn);

  async function fetchTrimmedLog(minutes) {
    const urls = [
      `/openquatt/debug-recording/download-range?seconds=${minutes * 60}`,
      `/openquatt/debug-recording/download?last_minutes=${minutes}`,
      `/openquatt/debug-recording/download`
    ];
    for (const url of urls) {
      try {
        const res = await fetch(url);
        if (!res.ok) continue;
        const logData = await res.json();
        if (logData && Array.isArray(logData.samples) && logData.samples.length > 0) {
          if (minutes > 0) {
            const intervalS = Number(logData.recording?.interval_s || 10);
            const maxSamples = Math.max(10, Math.round((minutes * 60) / intervalS));
            if (logData.samples.length > maxSamples) {
              logData.samples = logData.samples.slice(-maxSamples);
            }
          }
          return logData;
        }
      } catch (_) {}
    }
    return null;
  }

  function ensureDrawer() {
    if (drawer) return;
    drawer = document.createElement('aside');
    drawer.id = 'oq-ai-drawer';
    drawer.style.cssText = 'position:fixed;top:0;right:0;width:440px;max-width:100vw;height:100vh;z-index:99999;border-left:1px solid #1f2937;background:#030712;box-shadow:-8px 0 24px rgba(0,0,0,.45);display:none';

    const iframe = document.createElement('iframe');
    iframe.src = baseUrl + '/?embed=1';
    iframe.style.cssText = 'width:100%;height:100%;border:0';

    drawer.appendChild(iframe);
    document.body.appendChild(drawer);

    window.addEventListener('message', async (e) => {
      if (e.data?.type === 'OQ_EMBED_READY') {
        const logData = await fetchTrimmedLog(windowMinutes);
        if (logData) {
          iframe.contentWindow.postMessage({ type: 'OQ_LOGDATA', logData }, baseUrl);
        }
      } else if (e.data?.type === 'OQ_NAVIGATE' && e.data.href) {
        const u = new URL(e.data.href);
        history.pushState({}, '', u.search);
        window.dispatchEvent(new PopStateEvent('popstate'));
      }
    });
  }

  function toggleDrawer(forceState) {
    ensureDrawer();
    open = typeof forceState === 'boolean' ? forceState : !open;
    drawer.style.display = open ? 'block' : 'none';
    document.body.style.transition = 'margin-right 0.2s ease';
    document.body.style.marginRight = open ? '440px' : '0';

    if (open) {
      toggleBtn.textContent = '✕ Sluit AI';
      toggleBtn.style.right = '454px';
      toggleBtn.style.background = '#1f2937';
      toggleBtn.style.borderColor = '#374151';
    } else {
      toggleBtn.textContent = '✨ AI Hulp';
      toggleBtn.style.right = '16px';
      toggleBtn.style.background = '#ea580c';
      toggleBtn.style.borderColor = '#f97316';
    }
  }

  toggleBtn.onclick = () => toggleDrawer();
})();
